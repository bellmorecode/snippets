﻿<#
 Script: New-User.ps1
 Author: Scripter
 Version: 1.0
 Date: 17 Dec 13
 Description: Creates a new user with a scripter-supplied name. The user is placed in the Users container by default; 
  however, the scripter may specify a container for the new user with the Destination parameter.
 Requirements: Account Manager privileges; ActiveDirectory module
#>

# 3 - Define parameters $User (mandatory) and $Destination (optional)
Param([Parameter(Mandatory = $True)][String]$UserName, [String]$Destination = "cn=Users")

# 4 - Import the ActiveDirectory module


# 5 - Define variables


# 6 - Save an encrypted password to $SecureString


# 7 - Create the new user


