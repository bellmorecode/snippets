﻿# Unblock solution script files
$path = $MyInvocation.MyCommand.Path | Split-Path -Parent
Get-ChildItem -Path $path -Recurse -Filter "*.ps1" | Unblock-File

# Enable WinRM service
winrm quickconfig -quiet

# Enable CreddSSP authentication for student self-help
Enable-WSManCredSSP -Role Server -Force

Start-Sleep -Seconds 5