﻿#----------------------------------------------
# Global Variables
#----------------------------------------------
$LockedUsers = @()

#----------------------------------------------
# Unlock Functions
#----------------------------------------------

Function Get-LockedUser
{
  #Import the Active Directory module
  Import-Module ActiveDirectory

  $LockedUsers = Search-ADAccount -LockedOut -UsersOnly
  If ($LockedUsers -ne $Null)
    {
     $lbLocked.Enabled = $True
     $lblLocked.Enabled = $True
     $btnUnlock.Enabled = $True
     ForEach ($User in $LockedUsers)
       {$lbLocked.Items.Add($User.SAMAccountName)}
    }
  Else
    {$lblLocked.Text = "No Locked Users"}
}


Function Unlock-User
{
  $Temp = ConvertTo-SecureString -String "TempPwd8" -AsPlainText -Force
  $LockedUsers = Search-ADAccount -LockedOut -UsersOnly
  ForEach ($User in $LockedUsers)
  {
    Unlock-ADAccount -Identity $User.SAMAccountName
    Set-ADAccountPassword -Identity $User.SAMAccountName -NewPassword $Temp
    Set-ADUser -Identity $User.SAMAccountName -ChangePasswordAtLogon $True
  }
  $lblLocked.Text = "Locked Users"
  $lbLocked.Items.Clear()
  $btnUnlock.Enabled = $False
}     