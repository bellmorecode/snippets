﻿<#
 Script: New-User.ps1
 Author: Scripter
 Version: 1.0
 Date: 17 Dec 13
 Description: Creates a new user with a scripter-supplied name. The user is placed in the Users container by default; 
  however, the scripter may specify a container for the new user with the Destination parameter.
 Requirements: Account Manager privileges; ActiveDirectory module
#>

# 3 - Define parameters $User (mandatory) and $Destination (optional)
Param([Parameter(Mandatory = $True)][String]$UserName, [String]$Destination = "cn=Users")

# 4 - Import the ActiveDirectory module
Import-Module ActiveDirectory

# 5 - Define variables
New-Variable -Name Domain -Value "dc=Course969,dc=com"
New-Variable -Name UPNSuffix -Value "@course969.com"

# 6 - Save an encrypted password to $SecureString
$SecureString = Read-Host -Prompt Password -AsSecureString

# 7 - Create the new user
New-ADUser -Name $UserName `
                   -SamAccountName $UserName `
                   -UserPrincipalName ($UserName + $UPNSuffix) `
                   -AccountExpirationDate "MM/DD/YYYY" `
                   -AccountPassword $SecureString `
                   -ChangePasswordAtLogon $True `
                   -Enabled $True `
                   -Path ($Destination + "," + $Domain)

