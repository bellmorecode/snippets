﻿Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms

# Browse for file to open
$openFileDialog1 = New-Object System.Windows.Forms.OpenFileDialog
$openFileDialog1.Filter = "Text Files|*.txt|All Files|*.*"
$openFileDialog1.ShowDialog()
$UserListFile = $openFileDialog1.FileName

Function New-User ([string][Parameter(Mandatory=$True)]$UserName) {
   Try{
    New-ADUser -SamAccountName $_ `
               -Name $_ `
               -AccountPassword $SSPassword `
               -Enabled $True `
               -Path "OU=Demos,DC=Course,DC=com"
    }
    Catch [Microsoft.ActiveDirectory.Management.ADIdentityAlreadyExistsException] {Write-Host "Account already exists.  Skipping."}
    Catch {Write-Host "An error occured creating user account"}

    $HomeRoot = "\\D1\UserData\"
    $UserHome = $HomeRoot + $UserName

    If (-not(Test-Path $UserHome)){
        New-Item -Path $UserHome -ItemType Directory
        icacls ("$UserHome") /grant ("$Username" + ':(OI)(CI)F') /T
    }

}

$Password = [Microsoft.VisualBasic.Interaction]::InputBox("Please enter a password for your new accounts:","Password Required","Password8")
$UserList = Get-Content -Path $UserListFile
$SSPassword = ConvertTo-SecureString -String $Password -AsPlainText -Force

$UserList | ForEach-Object {New-User -UserName $_}

[System.Windows.Forms.MessageBox]::Show("Accounts deployed","Script Complete") | Out-Null