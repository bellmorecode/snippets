param (
    [string]$team="0",
    [string]$exercise="0"
    )

###############################
#region Initialize Variables 
$path = $MyInvocation.MyCommand.Path | Split-Path -Parent
$script = $exercise + "\" + $exercise + ".ps1"

# Prompt for team number and exercise, if necesary
Clear-Host
Write-Host "1535 - Team Exercise Restore Script" -ForegroundColor Green
Write-Host "-----------------------------------"

If ($team -eq 0){
    $team = Read-Host "Please enter the Team # to restore (e.g. 1)"
    if(-not($team)) { Throw "You must supply a value for Team #" }
}

If ($exercise -eq 0){
    $exercise = Read-Host "Please enter the exercise # to restore (e.g. 1.1)"
    if(-not($exercise -ilike "*.*")) { Throw "You must supply a value for exercise #" }
}

$teamsitebackuppath = "$path" + "\" + $exercise + "\Ex"+ $exercise +"teamsite.bak"
$pubsitebackuppath = "$path" + "\" + $exercise + "\Ex"+ $exercise +"pubsite.bak"


#endregion
################################

function Restore-Teamsite {

    $teamUrl = "http://mscserver/sites/team" + $team + "teamsite"

    Write-Host "`r`nRestoring Exercise $exercise Team Site for Team $team..."
    Restore-SPSite -Identity $teamUrl -Path $teamsitebackuppath -DatabaseServer "MSCServer" -DatabaseName "WSS_Content" -Force -Confirm:$false

    Write-Host "Setting Security..."
    Set-SPSite -Identity $teamUrl -OwnerAlias "MSC\team$team" -SecondaryOwnerAlias "MSC\Administrator"

    $siteweb = Get-SPWeb $teamUrl

    Write-Host "Renaming Security Groups"
    $grpMembers = $siteweb.Groups | Where-Object {$_.Name -ilike "Team*Site Members"}
    $grpMembers.Name = "Team $($team) Team Site Members"
    $grpMembers.Update()

    $grpVisitors = $siteweb.Groups | Where-Object {$_.Name -ilike "Team*Site Visitors"}
    $grpVisitors.Name = "Team $($team) Team Site Visitors"
    $grpVisitors.Update()

    $grpOwners = $siteweb.Groups | Where-Object {$_.Name -ilike "Team*Site Owners"}
    $grpOwners.Name = "Team $($team) Team Site Owners"
    $grpOwners.Update()

    Write-Host "Changing Owners Group"
    $grpOwners.Users | Where-Object {$_.Name -ilike "team*"} | ForEach-Object {$grpOwners.RemoveUser($_)}
    $NewUser = "MSC\team$team"
    $grpOwners.AddUser($siteweb.EnsureUser($NewUser))

    $siteweb.Update()

    Write-Host "Setting Title and Logo..."
    $siteweb.Title = "Team $team Team Site"
    $siteweb.SiteLogoUrl = "http://mscserver/sites/team" + $team + "teamsite/SiteAssets/msclogo.png"
    $siteweb.Update()
    $siteweb = Get-SPWeb $teamUrl

    # Update CSS URL
    If($siteweb.AlternateCssUrl -ne $null){
        $siteweb.AlternateCssUrl = $siteweb.AlternateCssUrl -replace "team..?team",("team"+$team+"team")
        $siteweb.Update()
    }

    #region Navigation links

    # Correct the top navigation bar title
    Write-Host "Configuring Navigation links..."
    $NavItem = $siteweb.Navigation.TopNavigationBar[0]
    $NavItem.Title = "Team $team Team Site"
    $NavItem.Update()

    # The following section adds the "Courses" Navigation Link from Exercise 1.2, skipping it for 1.1
    If ($exercise -ine "1.1"){
        $RecentCourses = ($siteweb.Navigation.QuickLaunch | Where-Object{$_.Title -ieq "Recent"}).Children | Where-Object {$_.Title -ieq "Courses"}
        If ($RecentCourses.Count -gt 0){$RecentCourses | ForEach-Object {$_.Delete()}}

        $OldCourses = $siteweb.Navigation.QuickLaunch | Where-Object {$_.Title -ieq "Courses"}
        If ($OldCourses.Count -gt 0){
            $OldCourses | ForEach-Object {$_.Delete()}
        }

        $siteweb.Update()
        $siteweb = Get-SPWeb $teamUrl

        $CoursesURL = "/sites/team"+$team+"teamsite/Lists/Courses"
        $CoursesNode = New-Object Microsoft.SharePoint.Navigation.SPNavigationNode("Courses",$CoursesURL)
        $siteweb.Navigation.QuickLaunch.AddAsLast($CoursesNode) | Out-Null

    }

    #endregion

    $siteweb.Update()
    $siteweb.Dispose()

}

function Restore-Pubsite {

    $pubUrl = "http://mscserver/sites/team" + $team + "pubsite"

    Write-Host "`r`nRestoring Exercise $exercise Pub Site for Team $team..."
    Restore-SPSite -Identity $pubUrl -Path $pubsitebackuppath -DatabaseServer "MSCServer" -DatabaseName "WSS_Content" -Force -Confirm:$false


    Write-Host "Setting Security..."
    Set-SPSite -Identity $pubUrl -OwnerAlias "MSC\Administrator" -SecondaryOwnerAlias "MSC\team$team"

    $pubweb = Get-SPWeb $pubUrl
    Write-Host "Setting Title"
    $pubweb.Title = "Team $team Publishing Site"
    $pubweb.SiteLogoUrl = $pubweb.SiteLogoUrl -replace "team..?pub",("team"+$team+"pub")

    Write-Host "Renaming Security Groups"
    $grpOwners = $pubweb.Groups | Where-Object {$_.Name -ilike "Team*Site Owners"}
    $grpOwners.Name = "Team $($team) Publishing Site Owners"
    $grpOwners.Update()    
    
    $grpMembers = $pubweb.Groups | Where-Object {$_.Name -ilike "Team*Site Members"}
    $grpMembers.Name = "Team $($team) Publishing Site Members"
    #$grpMembers.Owner = $grpOwners
    $grpMembers.Update()

    $grpVisitors = $pubweb.Groups | Where-Object {$_.Name -ilike "Team*Site Visitors"}
    $grpVisitors.Name = "Team $($team) Publishing Site Visitors"
    $grpVisitors.Update()

    Write-Host "Changing Owners Group"
    $grpOwners.Users | Where-Object {$_.Name -ilike "team*"} | ForEach-Object {$grpOwners.RemoveUser($_)}
    $NewUser = "MSC\team$team"
    $grpOwners.AddUser($pubweb.EnsureUser($NewUser))

    $pubweb.Update()

    #region Fix Pub Site DEFAULT page links and layout
    if($pubweb.GetFile("Pages/default.aspx").exists){
        Write-Host "Updating DEFAULT page link URLs..."
        $file = $pubweb.GetFile("Pages/default.aspx")
        $file.Checkout()

        $wpmgr = $pubweb.GetLimitedWebPartManager("Pages/default.aspx",[System.Web.UI.WebControls.WebParts.PersonalizationScope]::Shared)

        $wpmgr.WebParts | `
        ForEach-Object {
            If ($_.SummaryLinkStore -ne $null){
                $_.SummaryLinkStore = $_.SummaryLinkStore -replace "team..?pub",("team"+$team+"pub")
                $wpmgr.SaveChanges($_)
            }
        }

        Write-Host "Updating page layout..."
        $file.Properties["PublishingPageLayout"] = $file.Properties["PublishingPageLayout"] -replace "team..?pub",("team"+$team+"pub")
        $file.Update()

        $file.CheckIn("Help Team PowerShell script checkin")
        $file.Publish("Help Team PowerShell script published")

    }
    #endregion

    # Correct File Not Found URL using regular expressions
    $pubweb.site.FileNotFoundUrl = $pubweb.site.FileNotFoundUrl -replace "team..?pub",("team"+$team+"pub")
    $pubweb.Update()

    #region Update Managed Navigation Term Set
    Write-Host "Updating TermStore GUIDs..."
    $taxSession = Get-SPTaxonomySession -Site $puburl
    $termStore = $taxSession.TermStores["Managed Metadata Service"]
    $termgroup = $termStore.Groups | ?{$_.Name -ilike "*team$($team)pubsite"}

    # Set the permissions on the TermStore Group for the newly created site ID
    $termgroup.DeleteSiteCollectionAccess($termgroup.SiteCollectionAccessIds[0])
    $termgroup.AddSiteCollectionAccess($pubweb.site.id)
    $termStore.CommitAll()

    # Set the attached SiteID on the site navigation to the newly created site's ID
    $termgroup.TermSets["Site Navigation"].SetCustomProperty("_Sys_Nav_AttachedWeb_SiteId",$pubweb.site.id)
    $termStore.CommitAll()

    $NavSettings = New-Object Microsoft.SharePoint.Publishing.Navigation.WebNavigationSettings($pubweb)
    $NavSettings.GlobalNavigation.TermSetID = $termgroup.termsets["Site Navigation"].id
    $NavSettings.CurrentNavigation.TermSetID = $termgroup.termsets["Site Navigation"].id
    $NavSettings.Update()

    # Open the Navigation term set for editing
    $termgroup.TermSets["Site Navigation"].IsAvailableForTagging = $true
    $termgroup.TermSets["Site Navigation"].IsOpenForTermCreation = $true
    $termStore.CommitAll()

    # Add top level terms if necessary
    If (($termgroup.TermSets["Site Navigation"].Terms.Count) -eq 0){
        Write-Host "Adding terms to navigation term set..."
        $termgroup.TermSets["Site Navigation"].CreateTerm("About MSC",$termstore.DefaultLanguage)
        $termgroup.TermSets["Site Navigation"].CreateTerm("MSC Courses",$termstore.DefaultLanguage)
        $termgroup.TermSets["Site Navigation"].CreateTerm("MSC Instructors",$termstore.DefaultLanguage)
        $termgroup.TermSets["Site Navigation"].CreateTerm("MSC Locations",$termstore.DefaultLanguage)
        $termgroup.TermSets["Site Navigation"].CreateTerm("Contact Us",$termstore.DefaultLanguage)
        $termStore.CommitAll()
    }

    # Add the MSC Course sub-terms if necessary
    If (($termgroup.TermSets["Site Navigation"].Terms["MSC Courses"].Terms.Count) -eq 0){
        Write-Host "Adding sub-terms to navigation term set..."
        $termgroup.TermSets["Site Navigation"].Terms["MSC Courses"].CreateTerm("1531",$termstore.DefaultLanguage)
        $termgroup.TermSets["Site Navigation"].Terms["MSC Courses"].CreateTerm("1533",$termstore.DefaultLanguage)
        $termgroup.TermSets["Site Navigation"].Terms["MSC Courses"].CreateTerm("1534",$termstore.DefaultLanguage)
        $termgroup.TermSets["Site Navigation"].Terms["MSC Courses"].CreateTerm("1535",$termstore.DefaultLanguage)
        $termStore.CommitAll()
    }

        # Propogate updated terms to the site
        $taxSession.DefaultKeywordsTermStore.UpdateUsedTermsOnSite($pubweb.site)
        $taxSession.DefaultKeywordsTermStore.ReSyncHiddenList($pubweb.site)

    #endregion

    $pubweb.Update()
    $pubweb.Dispose()

    Write-Host "Restarting IIS (with noforce) to immediately enable termset navigation..."
    iisreset /noforce

    # Open the Term Store Management Tool as administrator one time to make the Term Store Group appear for TeamX
    $ie = New-Object -ComObject InternetExplorer.Application
    $ie.navigate2("http://mscserver/sites/team$($team)pubsite/_layouts/15/termstoremanager.aspx")

    # Wait for IE to load the page, then close it, twice.  It works....
    do
    {
        Start-Sleep -Seconds 1
    }
    while ($ie.Busy)
    $ie.Quit()

    $ie = New-Object -ComObject InternetExplorer.Application
    $ie.navigate2("http://mscserver/sites/team$($team)pubsite/_layouts/15/termstoremanager.aspx")

    # Wait for IE to load the page, then close it
    do
    {
        Start-Sleep -Seconds 1
    }
    while ($ie.Busy)
    $ie.Quit()


}

################################
#region Script Logic
    
Write-Host "Adding Microsoft.SharePoint.Powershell snapin..."
Add-PSSnapin Microsoft.SharePoint.Powershell

If (Test-Path $teamsitebackuppath){Restore-Teamsite} Else {Write-Host "No TeamSite backup for exercise $exercise" -ForegroundColor DarkRed}
If (Test-Path $pubsitebackuppath){Restore-Pubsite} Else {Write-Host "No PubSite backup for exercise $exercise" -ForegroundColor DarkRed}

Write-Host "`r`nDone with exercise $exercise restoration for Team $team." -ForegroundColor Green
Start-Sleep -Seconds 5

#endregion
################################