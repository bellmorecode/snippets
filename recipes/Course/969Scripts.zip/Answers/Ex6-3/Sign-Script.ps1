﻿Param ([Parameter (Mandatory = $True)] $FilePath)

[Array] $Cert = (Get-ChildItem -Path Cert:\CurrentUser\My -CodeSigningCert)[0]

Set-AuthenticodeSignature -Certificate $Cert -FilePath $FilePath

