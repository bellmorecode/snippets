﻿Function Get-IPRange ($Lower = 1, $Upper = 150)
{
  New-Variable -Name Network -Value '10.1.1.' -Option ReadOnly
  For ($Node = $Lower; $node -le $Upper; $Node ++) {"$Network$Node"}
}
# DONE