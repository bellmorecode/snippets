﻿<#
 Script: New-Group.ps1
 Author: Scripter
 Version: 1.0
 Date: 17 Dec 13
 Description: Creates a new HelpDesk Global Security group
 Requirements: Account Manager privileges; ActiveDirectory module
#>

# 11 - Define variables


# 12 - Import the ActiveDirectory module


# 13 - Create the new group


# 14 - Add your Helper user account to the group



