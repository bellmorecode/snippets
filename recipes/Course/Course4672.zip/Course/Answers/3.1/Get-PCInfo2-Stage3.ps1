﻿Add-Type -AssemblyName System.Windows.Forms

# Browse for file to open
$openFileDialog1 = New-Object System.Windows.Forms.OpenFileDialog
$openFileDialog1.Filter = "Text Files|*.txt|All Files|*.*"
$openFileDialog1.ShowDialog()
$PCListFile = $openFileDialog1.FileName

# Browse for file to save
$saveFileDialog1 = New-Object System.Windows.Forms.SaveFileDialog
$saveFileDialog1.Filter = "Excel Document|*.xlsx|All Types|*.*"
$saveFileDialog1.ShowDialog()
$ResultsFile = $saveFileDialog1.FileName

If (Test-Path -Path $ResultsFile){Remove-Item -Path $ResultsFile}

$ExcelApp = New-Object -comobject Excel.Application
 $ExcelApp.Visible = $True
 $WB = $ExcelApp.Workbooks.Add()
 $Sheet1 = $WB.Worksheets.Item(1)
 $CurrentRow = 1

$PCList = Get-Content -Path $PCListFile
$PCList | ForEach-Object {
    $Sheet1.Cells.Item($CurrentRow,1) = "$_"
    #$OutLine = "$_,"

    $OS = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $_
    $Sheet1.Cells.Item($CurrentRow,2) = "$($OS.Caption)"
    #$OutLine += $($OS.Caption)

    $RAM = Get-WmiObject -Class Win32_PhysicalMemory -ComputerName $_
    $ShortRAM = -join ([System.Math]::Round($RAM.Capacity /1GB,1),"GB")
    $Sheet1.Cells.Item($CurrentRow,3) = "$ShortRAM"
    #$OutLine += ",$ShortRAM"

    $CurrentRow += 1
}

$WB.SaveAs("$ResultsFile")
$ExcelApp.Quit()

[System.Windows.Forms.MessageBox]::Show("Inventory complete.  See $ResultsFile for results.","Inventory Results") | Out-Null
