﻿<#
 SCRIPT NAME: Test-Firewall
 AUTHOR: Scripter
 VERSION: 1.0
 DATE: 15 December 2013
 DESCRIPTION: Reads names of computers from Computers.txt, 
  Checks the status of the computer's firewall. Writes the computer name
  and firewall status to Verified.txt. Writes the names of unresponsive
  computers to Unresponsive.txt.
 REQUIREMENTS: Administrative privileges. PowerShell v3 or later. Computers.txt
#>

# 6 - Verify Administrator Privileges
#Requires -RunAsAdministrator

# 7 - Verify PowerShell Version is at least 3.0
#Requires -Version 3

# 8 - Assign the path to Computers.txt to $Computers


# 9 - If Computers.txt exists, open a scriptblock


  # 10 - Assign the path to the Verified log file
  

  # 11 - Create the Verified.txt log file


  # 12 - Assign the path to the Unresponsive log file


  # 13 - Create the Unresponsive.txt log file
  

  # 14 - Pass the computer names to a ForEach-Object loop
  

    # 15 - Send the name of the current computer to the console
    

    # 16 - Test to see if the computer is reachable


        # 17 - Assign status of firewall service on remote machine to $Status
        

        # 18 - Add computer name and firewall status to Verified.txt
        

     # 19 - Close the Test-Connection scriptblock
     

     # 20 - Add an Else clause to write the computer name to Unresponsive.txt
     

  # 21 - Close the ForEach-Object scriptblock}
  

# 22 - Close the Test-Path scriptblock

  
  
  