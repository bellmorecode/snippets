﻿<#
 Script: New-Group.ps1
 Author: Scripter
 Version: 1.0
 Date: 17 Dec 13
 Description: Creates a new HelpDesk Global Security group
 Requirements: Account Manager privileges; ActiveDirectory module
#>

# 11 - Define variables
New-Variable -Name GroupName -Value "HelpDesk"
New-Variable -Name Destination -Value "cn=Users, dc=course969, dc=com"
New-Variable -Name Category -Value "Security"
New-Variable -Name Scope -Value "Global"

# 12 - Import the ActiveDirectory module
Import-Module ActiveDirectory

# 13 - Create the new group
New-ADGroup -Name $GroupName `
            -SamAccountName $GroupName `
            -GroupCategory $Category `
            -GroupScope $Scope `
            -Path $Destination

# 14 - Add your Helper user account to the group
Add-ADGroupMember -Identity "cn=$GroupName,$Destination" -Members "cn=Helper,$Destination"



