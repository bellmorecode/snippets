﻿<#
 Script: Broken.ps1
 Author: Scripter
 Version: 1.0
 Date: 17 Dec 13
 Description: Returns information about non-functional devices reported by Device Manager
 Requirements: Administrative privileges
#>
# Verify script is running with elevated privileges
#Requires -RunAsAdministrator

# Define a mandatory parameter $Input
# $Input is a text file with the names of computers, one name per line
Param([Parameter(Mandatory = $True)][String]$Names)

# Create Log.csv
$Log = 'C:\Course969\Exercises\Ex7-2\Broken.csv'
New-Item -Path $Log -ItemType File -Force | Out-Null

# Define the column headers for the CSV file
$ComputerHeader = "Computer Name,"
$DataHeader = "PnP Device Status"
$CSVHeader = $ComputerHeader + $DataHeader
Add-Content -Path $Log -Value $CSVHeader

# Read the list of computer names from the input file
$Computers = Get-Content -Path $Names

# 29  Build WQL Query
$Query = "SELECT Name, PnPDeviceID "
$Query += "FROM Win32_PnPEntity "
$Query += "WHERE ConfigManagerErrorCode <> 0"

# Enumerate the computers
ForEach ($Computer in $Computers)
{
  # If the computer is online, continue...
  If (Test-Connection -ComputerName $Computer -ErrorAction SilentlyContinue) 
  {
    # Write the computer name to $Data
    $Data = $Computer + ","

    # 30 - Perform a WQL query to return information about the computer's non-functional devices
    $Result = Get-WmiObject -Query $Query  -ComputerName $Computer

    # 31 - Test for presence of non-functional devices
    If ($Result -eq $Null)

      # 32 - Indicate no non-functional devices
     {$Data += "All devices are functioning normally"}

    Else

      # 33 - Identify non-functional devices
     {$Data += $Result.Name + "," + $Result.PnPDeviceID}

    # Append $Data to $Log
    Add-Content -Path $Log -Value $Data

    # Close the IF scriptblock
  }

# Close the FOREACH-OBJECT scriptblock
}

# Tell the user we're done
Write-Host "Done checking device status"

