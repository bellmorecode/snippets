﻿$BadPwd = ConvertTo-SecureString -String "BadPassword" -Force -AsPlainText
$Users = Get-ADUser -Filter {Name -like "User*"} | Get-Random -Count 3
ForEach ($User in $Users)
  {
   $Creds = New-Object System.Management.Automation.PSCredential($User.Name,$BadPwd)
   For ($i=1; $i -le 5; $i++) {New-PSSession -ComputerName D1 -Credential $Creds -ErrorAction SilentlyContinue}
   Write-Host  $User.Name
   Start-Sleep -Seconds 3
  }