﻿Add-Type -AssemblyName Microsoft.VisualBasic
$Password = [Microsoft.VisualBasic.Interaction]::InputBox("Please enter a password for your new accounts:","Password Required","Password8")
$UserList = Get-Content -Path "C:\Course\Exercises\3.2\Users.txt"
$SSPassword = ConvertTo-SecureString -String $Password -AsPlainText -Force

$UserList | ForEach-Object {
    Try{
    New-ADUser -SamAccountName $_ `
               -Name $_ `
               -AccountPassword $SSPassword `
               -Enabled $True `
               -Path "OU=Demos,DC=Course,DC=com"
    }
    Catch {Write-Host "An error occured creating user account"}
    }