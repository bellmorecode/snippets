﻿<#
 Script: Get-Inventory.ps1
 Author: Scripter
 Version: 1.0
 Date: 17 Dec 13
 Description: Returns information about the specified computer's CPU, RAM,
  Hard Drive, Operating System, and Display
 Requirements: Administrative privileges
#>
# 2 - Verify script is running with elevated privileges
#Requires -RunAsAdministrator

# 3 - Define a mandatory parameter $Names
# $Names is a text file with the names of computers, one name per line
Param([Parameter(Mandatory = $True)][String]$Names)

# 4 - Create Log.csv
$Log = 'C:\Course969\Exercises\Ex7-2\Log.csv'
New-Item -Path $Log -ItemType File -Force | Out-Null

# 5 - Define the column headers for the CSV file
$ComputerHeader = "Computer Name,"
$CPUHeader = "CPU Cores,CPU Description,CPU Speed (MHz),"
$RAMHeader = "Visible Memory (MB),"
$DriveHeader = "Drive Capacity (MB),Drive Free Space (MB),"
$DisplayHeader = "Screen Width,Screen Height,"
$OSHeader = "Operating System"
$CSVHeader = $ComputerHeader + $CPUHeader + $RAMHeader + $DriveHeader + $DisplayHeader + $OSHeader
Add-Content -Path $Log -Value $CSVHeader

# 6 - Read the list of computer names from the input file
$Computers = Get-Content -Path $Names

# 7 - Enumerate the computers
ForEach ($Computer in $Computers)
{
  # 8 - If the computer is online, continue...
  If (Test-Connection -ComputerName $Computer) 
  {
    # 9 - Write the computer name to $Data
    $Data = $Computer + ","

    # 10 - Use WMI to return information about the computer's CPUs
    $CPU = Get-WmiObject -Class Win32_Processor  -ComputerName $Computer

    # 11 - Write the number of CPU cores to $Data as a string
    $Data += [String]$CPU.NumberOfCores + ","

    # 12 - Write the CPU description to $Data
    $Data += $CPU.Description + ","

    # 13 - Write the speed of the first CPU core (the speed of all cores should be the same)
    $Data += [String]$CPU.CurrentClockSpeed + ","

    # 14 - Return a WMI object representing the OS
    $OS = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $Computer

    # 15 - Return the visible memory, round, divide by KB
    $Mem = [System.Math]::Round($OS.TotalVisibleMemorySize / 1KB)

    # 16 - Save the memory size as a string to $Data
    $Data += [String]$Mem + ","

    # 17 - Create a WMI object bound to the C: drive
    $Drive = Get-WmiObject -Class Win32_LogicalDisk -Filter 'DeviceID = "C:"' -ComputerName $Computer

    # 18 - Divide the size by KB and round; save to $Size
    $HDSize = [String][System.Math]::Round($Drive.Size / 1MB)
    $HDFree = [String][System.Math]::Round($Drive.FreeSpace / 1MB)

    # 19 - Save the drive info to $Data as strings
    $Data += $HDSize + "," + $HDFree + ","

    # 20 - Get display properties
    $Display = Get-WmiObject -Class Win32_DisplayConfiguration -ComputerName $Computer

    # 21 - Add the horizontal and vertical screen dimensions in Pels (Picture Elements)
    $Data += [String]$Display.PelsWidth + "," + [String]$Display.PelsHeight + ","

    # 22 - Append the OS caption
    $Data += $OS.Caption

    # 23 - Append $Data to $Log
    Add-Content -Path $Log -Value $Data

  # 24 - Close the IF scriptblock
  }

# 25 - Close the FOREACH scriptblock
}

# Tell the user we're done
Write-Host "Done with computer inventory"

