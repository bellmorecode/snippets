﻿Function Get-IPRange ($Lower = 1, $Upper = 150)
{
<#
.SYNOPSIS
Returns all IP addresses between 10.1.1.<Lower> and 10.1.1.<Upper>
.DESCRIPTION
Returns all IP addresses between 10.1.1.<Lower> and 10.1.1.<Upper> as strngs.
If either <Lower> or <Upper> is not specified, default values of 1 and 150 are used
.PARAMETER Lower
The lower limit of the IP range; by default, Lower is 10
.PARAMETER Upper
The upper limit of the IP range; by default, Upper is 150
.EXAMPLE
Get-IPRange -Lower 20 -Upper 30
#>
  New-Variable -Name Network -Value '10.1.1.' -Option ReadOnly
  For ($Node = $Lower; $node -le $Upper; $Node ++) {"$Network$Node"}
}
Export-ModuleMember -Function Get-IPRange
# DONE