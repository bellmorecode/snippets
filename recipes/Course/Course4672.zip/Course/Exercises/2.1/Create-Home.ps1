﻿
$HomeRoot = "\\D1\UserData\"
$UserName = "User1"
$UserHome = $HomeRoot + $UserName

If (-not(Test-Path $UserHome)){
    New-Item -Path $UserHome -ItemType Directory
    # Grant user full control to the new home folder
    icacls ("$UserHome") /grant ("$Username" + ':(OI)(CI)F') /T
}
