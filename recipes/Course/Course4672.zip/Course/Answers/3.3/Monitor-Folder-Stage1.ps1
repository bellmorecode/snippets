﻿$FSWatcher = New-Object System.IO.FileSystemWatcher -Property @{Path = 'C:\Course\Exercises\3.3\Monitor';Filter = '*.*'}

$Deleted = 
{Add-Content -Value $($event.sourceEventArgs.FullPath) -Path "C:\Course\Exercises\3.3\FileDeletions.txt"}

Register-ObjectEvent -InputObject $FSWatcher `
                     -EventName Deleted `
                     -SourceIdentifier “File Deleted” `
                     -Action $Deleted

