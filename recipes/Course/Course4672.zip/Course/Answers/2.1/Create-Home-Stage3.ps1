﻿Function Create-Home ([string]$ServerName="D1",[string][Parameter(Mandatory=$True)]$UserName) {
    $HomeRoot = "\\$ServerName\UserData\"
    $UserHome = $HomeRoot + $UserName

    If (-not(Test-Path $UserHome)){
        New-Item -Path $UserHome -ItemType Directory
        # Grant user full control to the new home folder
        icacls ("$UserHome") /grant ("$Username" + ':(OI)(CI)F') /T
    }
}