﻿Add-Type -AssemblyName System.Windows.Forms

# Browse for file to open
$openFileDialog1 = New-Object System.Windows.Forms.OpenFileDialog
$openFileDialog1.Filter = "Text Files|*.txt|All Files|*.*"
$openFileDialog1.ShowDialog()
$PCListFile = $openFileDialog1.FileName

# Browse for file to save
$saveFileDialog1 = New-Object System.Windows.Forms.SaveFileDialog
$saveFileDialog1.Filter = "CSV File|*.csv|All Types|*.*"
$saveFileDialog1.ShowDialog()
$ResultsFile = $saveFileDialog1.FileName

If (Test-Path -Path $ResultsFile){Remove-Item -Path $ResultsFile}

$PCList = Get-Content -Path $PCListFile
$PCList | ForEach-Object {
    $OutLine = "$_,"

    $OS = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $_
    $OutLine += $($OS.Caption)

    $RAM = Get-WmiObject -Class Win32_PhysicalMemory -ComputerName $_
    $ShortRAM = -join ([System.Math]::Round($RAM.Capacity /1GB,1),"GB")
    $OutLine += ",$ShortRAM"

    Add-Content -Value $OutLine -Path $ResultsFile

}

[System.Windows.Forms.MessageBox]::Show("Inventory complete.  See $ResultsFile for results.","Inventory Results") | Out-Null
