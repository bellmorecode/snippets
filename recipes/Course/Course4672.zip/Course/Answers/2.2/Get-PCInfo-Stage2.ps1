﻿Param ([Parameter(Mandatory=$True)]$PCListFile,[Parameter(Mandatory=$True)]$ResultsFile,[Switch]$RAM)

If (Test-Path -Path $ResultsFile){Remove-Item -Path $ResultsFile}

$PCList = Get-Content -Path $PCListFile
$PCList | ForEach-Object {
$OutLine = "$_,"

$OS = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $_
$OutLine += $($OS.Caption)

If($RAM) {
    $FullRAM = Get-WmiObject -Class Win32_PhysicalMemory -ComputerName $_
    $ShortRAM = -join ([System.Math]::Round($FullRAM.Capacity /1GB,1),"GB")
    $OutLine += ",$ShortRAM"
}

Add-Content -Value $OutLine -Path $ResultsFile

}